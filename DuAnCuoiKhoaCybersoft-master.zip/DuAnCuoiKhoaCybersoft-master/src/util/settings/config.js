export const DOMAIN = "https://airbnb.cybersoft.edu.vn";
export const TOKENCYBERSOFT =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5Mb3AiOiJCb290Y2FtcCBTw6FuZyAwMiIsIkhldEhhblN0cmluZyI6IjI0LzA4LzIwMjIiLCJIZXRIYW5UaW1lIjoiMTY2MTI5OTIwMDAwMCIsIm5iZiI6MTYzNzM0MTIwMCwiZXhwIjoxNjYxNDQ2ODAwfQ.Jyh-ALPYBzDojZwAY5mCMSzdNFvh1i-5lNzT3RhI0nU";
export const ACESSTOKEN = "accessToken";
export const USER_LOGIN = "USER_LOGIN";
