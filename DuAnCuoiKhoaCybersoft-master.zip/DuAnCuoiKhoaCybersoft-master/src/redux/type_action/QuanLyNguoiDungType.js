export const GET_USER_DETAIL = "GET_USER_DETAIL";
export const GET_USER_LIST = "GET_USER_LIST";
