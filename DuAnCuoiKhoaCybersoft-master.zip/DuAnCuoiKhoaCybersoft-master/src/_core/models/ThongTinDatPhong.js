export class ThongTinDatPhong {
  roomId = "";
  checkIn = "";
  checkOut = "";
  constructor(){}
}
